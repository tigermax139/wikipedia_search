// select query from store
export const getQuery = state => {
    return state.query.query;
};