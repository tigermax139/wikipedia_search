export default {
    wikiURL          : 'https://en.wikipedia.org/w/api.php?format=json&origin=*&action=query&generator=search&gsrnamespace=0&gsrlimit=10&prop=pageimages|extracts&pilimit=max&exintro&explaintext&exsentences=1&exlimit=max&gsrsearch=',
    googleSuggest    : 'https://dk1ecw0kik.execute-api.us-east-1.amazonaws.com/prod/query?query='
    //googleSuggestURL : 'http://suggestqueries.google.com/complete/search?output=toolbar&hl=en&q='
}