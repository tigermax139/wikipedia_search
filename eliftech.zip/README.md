#Application
###How to start?

run follow command in shell in root this project

> npm i 

> npm run start

> open [locallhost:3000](localhost:3000) in your browser

